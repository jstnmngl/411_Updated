<?php
    function getDBConnection() {
        $dsn = 'mysql:host=localhost;dbname=ymcavolunteer';
        $username = 'root';
        $password = '';

        try {
            $db = new PDO($dsn, $username, $password);
        } catch (PDOException $e) {
            $errorMessage = $e->getMessage();
            include '../view/errorPage.php';
            die;
        }
        return $db;
    }
?>