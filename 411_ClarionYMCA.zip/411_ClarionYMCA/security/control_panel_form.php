<?php
	$title = "Control Panel ";
	require '../security/headerInclude.php';

	require '../security/footerInclude.php';
?>
