<?php
    session_start();
    require_once("../security/model.php");
    require_once '../model/model.php';

    if (isset($_POST['action'])) { // Checks get and post
        $action = $_POST['action'];
    } else if (isset($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        include('../view/index.php'); //default action
        exit();
    }

    switch($action) {
        case 'AdminActivities':
            include('../view/activitiesAdminView.php');
            break;
        case 'Home':
            include('../view/index.php');
            break;
        case 'Introduction':
            include('../view/introductionPage.php');
            break;
        case 'Handbook':
            include('../view/handbookForm.php');
            break;
        case 'Application':
            include('../view/applicationPage.php');
            break;
        case 'Waiver':
            include('../view/waiverPage.php');
            break;
        case 'CriminalClearance':
            include('../view/criminalClearance.php');
            break;
        case 'ChildAbuseClearance':
            include('../view/abuseClearance.php');
            break;
        case 'SignIn':
            include('../security/login_form.php');
            break;
        case 'SignUp':
            include('../view/registerPage.php');
            break;
        case 'AdminSupervisors':
            include('../view/supervisorsAdminView.php');
            break;
        case 'AdminHandbook':
            include('../view/adminHandbook.php');
            break;
        case 'AdminApplication':
            include('../view/adminApplication.php');
            break;
        case 'AdminWaiver':
            include('../view/adminWaiver.php');
            break;
        case 'AdminHome':
            include('../view/adminHome.php');
            break;
        case 'CompleteApplication':
            include('../view/completedPage.php');
            break;
        case 'ForgotPassword':
            include('../view/forgottenPassword.php');
            break;
        case 'AddUserForm':
            include('../security/add_user_form.php');
            break;
    }
?>