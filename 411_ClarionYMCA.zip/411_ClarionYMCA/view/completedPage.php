<?php
    $title = "Volunteer Completed";
    require_once '../view/headerInclude.php';
?>

    <script>
        var module1 = 1;
        var module2 = 1;
        var module3 = 1;
        var module4 = 1;
        var module5 = 1;
        var sum = module1+module2+module3+module4+module5;
        localStorage.setItem("percentComplete", sum);
        progress();
    </script>

<section id="main" class="align-content-center">
    <div class="text-center">
        <h1>APPLICATION SUBMITTED!</h1>
        <p>
            Thank you for taking the time to apply to volunteer with us and for choosing to step forward and make a  positive difference in the lives of others.
        </p>

        <br>

        <p>
            We usually respond to applicants within 5 working days.
        </p>

        <br>

        <p>
            See you soon!
        </p>
    </div>
</section>

<?php
    require_once '../view/footerInclude.php';
?>