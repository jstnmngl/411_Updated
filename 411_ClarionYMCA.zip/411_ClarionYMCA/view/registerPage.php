<?php
    $title = "Register Volunteer";
    require_once '../view/headerInclude.php';
?>
    <div class="align-content-center">
        <h1>Register Volunteer</h1>
        <form action="../security/index.php?action=SecurityProcessUserAddEdit" method="post">

            First Name*: <input type="text" name="firstName" size="20" value="" autofocus required ><br/><br/>

            Last Name*: <input type="text" name="lastName" size="20" value=""><br/><br/>

            Birth Date*: <input type="date" name="birthDate" value ="<?php echo date('Y-m-d') ?>" size="20"><br/><br/>

            Password*: <input type="password" name="password" size="20" value=""><br/><br/>

            Email*: <input type="text" name="email" size="20" value=""><br/><br/>

            Date*: <input type="date" name="dateRegistered" value ="<?php echo date('Y-m-d') ?>" size="20" readonly><br/><br/>

            <br/>

            <input type="submit" value="Submit" />
        </form>
    </div>

<?php
    require_once '../view/footerInclude.php';
?>