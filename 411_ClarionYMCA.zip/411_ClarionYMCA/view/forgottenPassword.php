<!--Author: Josh Dunleavy
    Purpose: This form will allow a user who forgot their password
    to type in there email and have a new password sent to said email.
    LastModified: 
-->

    <!--Adds title to tab and header to page-->
    <?php
        //Variable used to add title to the tab
        $title = "Change Password";
        require_once '../view/headerInclude.php';
    ?>

    <section id="main" class="align-content-center">
        <div class="text-center card">
            <!--Heading of page-->
            <h1>Change Current Password</h1>
            <p class="text-center">If you have forgotten your password, enter the email you used for your account to be sent a new password</p>

            <!-- Form will allow a volunteer to enter their account email and be send a new password-->
            <form>
                <!--Label for Email-->
                <label for="email">
                    Email Address:
                </label>
                <!--Input is set to email type, id email binds it to label that has for="email" -->
                <input type="email" id="email" name="email">
                <!--Submits information-->
                <!--m-2 adds margins -->
                <input class="m-3 rounded" type="submit" name="submit">
            </form>
        </div>
    <!--End of section -->
    </section>

    <!--Adds footer to game-->
    <?php
        require_once '../view/footerInclude.php';
    ?>
    <!-- -->