<?php
    $title = "Error";
    require '../view/headerInclude.php';
?>

    <br>
    <h3><?php echo $errorMessage; ?></h3>

<?php
    require '../view/footerInclude.php';
?>