<?php
    $title = "Admin Clearances";
    require_once '../view/headerInclude.php';
?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Clearances for *User by ID*</h1>
            <p>
                    <!-- WILL Pull dates from database -->
                Child abuse date submitted: <input type="date" value ="<?php echo date('Y-m-d') ?>">
                Criminal Check date submitted: <input type="date" value ="<?php echo date('Y-m-d') ?>">
                <br>
                <img src = "getChildAbuseImage" alt = "Child Abuse Image Here" />
                <img src = "getCriminalCheckImage" alt = "Criminal Check Image Here" />
                <br>
                <button>Delete Child Abuse Image</button><button>Delete Criminal Check Image</button>
            </p>
            <button>Save</button>
            <button>Back to User Information</button>
        </div>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>