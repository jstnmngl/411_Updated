<h1>Clarion YMCA Volunteer Registration</h1>

<?php
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $birthDate = $_POST['birthDate'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($firstName)) {
        echo "<h1> You must provide a first name to register.</h1> ";
    } else {
        if (empty($lastName)) {
            $msg = 'You must provide a last name to register.';
        } else if(empty($birthDate)) {
            $msg = 'You must provide a valid birth date to register.';
        } else if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $msg = 'You must provide a valid email to register.';
        } else {
            $msg = 'Please continue with the volunteer process';

            $file = fopen('../DataFiles/members.csv', 'ab');
            fputcsv($file,
                array($firstName, $lastName, $birthDate, $email, $password));
            fclose($file);
        }

        echo "<h3>$firstName,<br/>$msg</h3>";
    }

    require '../view/footerInclude.php';
?>