<!--Author: Josh Dunleavy
    Purpose: This page will show all current Supervisors, it will allow an admin to 
    add, delete, save and a back button to the previous page
    LastModified: 
     -->
    <!--Adds title to tab and header to page-->
    <?php
        //Variable used to add title to the tab
        $title = "Supervisors Admin";
        require_once '../view/headerInclude.php';
    ?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <!--Heading of page-->
            <h1>Supervisors Admin</h1>
            
        </div>
    <!--End of section -->
    </section>
    <!-- Table hold supervisors names and the activities that they supervise-->
    <table class="table table-striped table-dark table-bordered">
        <!--Table row for headings-->
        <tr>
            <!--Sets scope of table header to one column-->
            <th scope="col">
                Supervisor Name
            </th>
            <!--Sets scope of table header to one column-->
            <th scope="col">
                Activities supervised
            </th>
        </tr>
        
        <tr>
            <!--Row for Supervisors names-->
            <td>
                James Collins
            </td>
            <!--Row for the activities this supervisor supervises-->
            <td>
                Swimming Director
            </td>
        </tr>

        <tr>
            <!--Row for Supervisors names-->
            <td>
                
            </td>
            <!--Row for the activities this supervisor supervises-->
            <td>
                
            </td>
        </tr>
    </table>

    <section>
        <!--Form will allow a Admin to a new supervisor and the activity that they supervise-->
        <form>
            <!--Label for firstName-->
            <label for="firstName">
                First Name:
            </label>    
            <!--input to hold supervisors first name-->
            <input type="text" name="firstName" id="firstName"><br>
            <!--Label for lastName-->
            <label for="lastName">
                Last Name:
            </label> 
            <!--input to hold supervisors last name-->
            <input type="text" name="lastName" id="lastName"><br>
            <!--Label to hold Activities supervised-->
            <label for="supervisorActivities">
                Activities supervised:
            </label> 
            <!--input to hold activity that a supervisor supervises -->
            <input type="text" name="supervisorActivities" id="supervisorActivities">
        </form>
    </section>
    <!--This section holds forms that have buttons-->
    <div>
        <!-- will hold a button will add a new supervisor-->
        <button type="submit">
            Add New Supervisor
        </button>
        <!--will hold to delete a supervisor-->
        <button type="submit">
            Delete Supervisor
        </button>  
        <!-- will hold a button to save and changes made to a supervisor-->
        <button type="submit">
            Save changes to Supervisor
        </button>
        <!-- will hold a button to return to previous page-->
        <button class="hidden" type="submit">
            Back to Previous page
    </button>
    </div>
<!--Adds footer to game-->
<?php
    require_once '../view/footerInclude.php';
?>
<!-- -->



