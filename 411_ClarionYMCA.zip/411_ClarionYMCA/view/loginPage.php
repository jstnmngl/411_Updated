<?php
    $title = "Sign In";
    require_once '../view/headerInclude.php';
?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Sign In</h1>
            <form>
                Email:<br>
                <input type="text" name="email"><br>
                Password:<br>
                <input type="text" name="password">
            </form>

            <br>

            <button type="submit" onclick="location.href='../controller/controller.php?action=ForgotPassword'">Forgot Password?</button>
            <button type="button" href="#">Sign In</button>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>
