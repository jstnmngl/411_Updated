<!DOCTYPE html>
<html lang="en">
<head>
    <title>
        <?php echo $title ?>
    </title>
    <link rel="shortcut icon" type="image/icon" href="../images/favicon.ico"
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/main.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="../js/main.js"></script>
</head>

<body>
<div class="container-fluid">
    <header class="row">
        <section id="headleft" class="d-none d-sm-block col-sm-2">
            <img id="headleftimage" src="../images/ymca_transparent.png"/>
        </section>

        <section id="headmiddle" class="d-none d-sm-block col-10 col-sm-8 text-center">
            <h1>Clarion YMCA Volunteer</h1>
        </section>

        <section id="headright" class="d-none d-sm-block col-2">

        </section>
    </header>

<?php
    require_once '../view/progressBar.php';
    require_once '../view/navInclude.php';
?>