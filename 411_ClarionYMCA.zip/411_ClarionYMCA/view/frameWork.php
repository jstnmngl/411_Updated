<!--Author: Josh Dunleavy
    Purpose: 
    LastModified: 
     -->
<!--Adds title to tab and header to page-->
    <?php
        //Variable used to add title to the tab
        $title = "";
        require_once '../view/headerInclude.php';
    ?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <!--Heading of page-->
            <h1></h1>
            
        </div>
    <!--End of section -->
    </section>

    <!--Adds footer to game-->
    <?php
        require_once '../view/footerInclude.php';
    ?>
    <!-- -->