<?php
    $title = "Criminal Record Clearances";
    require_once '../view/headerInclude.php';
?>

    <script>
        var module1 = 1;
        var module2 = 1;
        var module3 = 1;
        var module4 = 0;
        var module5 = 0;
        var sum = module1+module2+module3+module4+module5;
        localStorage.setItem("percentComplete", sum);
        progress();
    </script>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Criminal Clearance</h1>
            <p>
                We ask all volunteers to provide us with a copy of their PA Child Abuse Check and their Criminal Record Check.
            </p>

            <br>

            <p>
                If you already have a check dated within the last 5 years - please upload a scan/screenshot of them here.
                <br><br>
                PA State Criminal Check:<input type = "file" id = "CriminalCheckFile">
            </p>

            <br>

            <p>
                If you are applying for these checks, please follow the links below. These clearances are free for volunteers.
            </p>

            <br>

            <div>
                <ul><a href="https://epatch.state.pa.us/Home.jsp">PA Criminal Background Check</a></ul>
            </div>

            <br>

            <p>
                For support in applying for these checks - please click and follow the guides below.
            </p>

            <br>

            <div>
                <ul><a href="../guides/CriminalRecordCheckGuide.pdf">Guide: PA Criminal Background Check</a></ul>
            </div>
            <button id="progressBar" onclick="location.href='../controller/controller.php?action=Waiver'">Next</button>
        </div>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>