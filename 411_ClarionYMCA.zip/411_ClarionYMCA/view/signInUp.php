<?php
    $title = "Welcome to Volunteering";
    require_once '../view/headerInclude.php';
?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Sign In/ Sign Up</h1>
            <button onclick="location.href='../view/loginPage.php'" type="button">Sign In</button>
            <button onclick="location.href='../view/registerPage.php'" type="button"> Sign Up</button>
        </div>

    </section>

<?php
    require_once '../view/footerInclude.php';
?>