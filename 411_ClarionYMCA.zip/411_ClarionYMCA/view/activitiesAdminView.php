<!--Author: Josh Dunleavy
    Purpose: This page will be used to see all Volunteers and the activities they take part in.
    Also it will allow for Editing of Volunteer Activities, Saving of said changes and a back button to return to previous page
    LastModified: 
     -->
<!--Adds title to tab and header to page-->
<?php
    //Variable used to add title to the tab
    $title = "Activites Admin View";
    require_once '../view/headerInclude.php';
?>

<section id="main" class="align-content-center">
    <div class="text-center">
        <!--Heading of page-->
        <h1>Activities Admin View</h1>
       
    </div>
<!--End of section -->
</section>

<table class="table table-striped table-dark table-bordered">
    <!--Table row for headings-->
    <tr>
        <!--Sets scope of table header to one column-->
        <th scope="col">
            Name
        </th>
        <!--Sets scope of table header to one column-->
        <th scope="col">
            Flag Football
        </th>    
        <!--Sets scope of table header to one column-->
        <th scope="col">
            Soccer
        </th>
        <!--Sets scope of table header to one column-->
        <th scope="col">
            Basketball
        </th>
        <!--Sets scope of table header to one column-->
        <th scope="col">
            Other
        </th>
    </tr>

    <!--Row -->
    <tr>
        <td>
            Matt Chappy
        </td>
            
        <td>
        No
        </td>
        <td>
        No
        </td>

        <td>
            No
        </td>

        <td>
            No
        </td>
    </tr>
    <tr>
        <td>
            
        </td>
            
        <td>
       
        </td>
        <td>
        
        </td>

        <td>
            
        </td>

        <td>
            
        </td>
    </tr>

</table>
    <!--This section holds forms that have buttons-->
    <div>
        <!--This form will hold a button to Edit user information-->
        <form method="get" action="">
            <button class="" type="submit">
                Edit Information
            </button>
            <!--This form will hold a button to edit forms-->
            <!--BUTTON SHOULD BE HIDDEN UNTIL EDIT BUTTON HAS BEEN CLICKED--> 
            <button type="submit">
                Save changes
            </button>
            <!--This form will hold a button to return to previous page-->
            <button class="hidden" type="submit">
                Back to Previous page
            </button>
        </form>
    </div>

<!--Adds footer to game-->
<?php
    require_once '../view/footerInclude.php';
?>
<!-- -->