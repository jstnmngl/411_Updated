<?php
    $title = "Volunteer Clearances";
    require_once '../view/headerInclude.php';
?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Volunteer Clearances View</h1>
            <p>
                We ask all volunteers to provide us with a copy of their PA child abuse check and their Criminal Record Check.
            </p>

            <br>

            <p>
                If you already have a check dated within the last 5 years - please upload a scan/screenshot of them here.
                <br><br>
                PA Child Abuse Clearance: <input type = "file" id = "ChildAbuseFile"> PA State Criminal Check:<input type = "file" id = "CriminalCheckFile">
            </p>

            <br>

            <p>
                If you are applying for these checks, please follow the links below. These clearances are free for volunteers.
            </p>

            <br>

            <div>
                <ul><a href="https://epatch.state.pa.us/Home.jsp">PA Criminal Background Check</a></ul>
                <ul><a href="https://www.compass.state.pa.us/cwis/public/home">PA Child Abuse History Check</a></ul>
            </div>

            <br>

            <p>
                For support in applying for these checks - please click and follow the guides below.
            </p>

            <br>

            <div>
                <ul><a href="../guides/CriminalRecordCheckGuide.pdf">Guide: PA Criminal Background Check</a></ul>
                <ul><a href="../guides/ChildAbuseCheckGuide.pdf">Guide: PA Child Abuse History Check</a></ul>
            </div>
            <button>Next</button>
        </div>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>