<?php
    $title = "Application";
    require_once '../view/headerInclude.php';
?>

    <script>
        var module1 = 1;
        var module2 = 1;
        var module3 = 0;
        var module4 = 0;
        var module5 = 0;
        var sum = module1+module2+module3+module4+module5;
        localStorage.setItem("percentComplete", sum);
        progress();
    </script>

    <form action="../security/index.php?action=SecurityProcessUserAddEdit" method="post">
    <br>
    <div style="background-color: white; float: left">
        <img style="align: left; width:120px; height: 120px; padding-left: 10px" src="../images/ymca_transparent.png" />

    </div>
    <div style="background-color: white">
        <h1 style=" font-weight: bold;font-size: 65px;text-align:center; ">VOLUNTEER APPLICATION</h1>
        <h1 style=" font-weight: bold;font-size: 32px;text-align:center; ">SCENIC RIVERS YMCA </h1>
        <p style=" font-weight: bold;float: left;padding-left: 10px; padding-right: 40px">
            <br>
            FOR YOUTH DEVELOPMENT®<br>
            FOR HEALTHY LIVING<br>
            FOR SOCIAL RESPONSIBILITY<br>
        </p>
        <p style=" font-weight: bold;float: left; padding-right: 40px">
            OIL CITY YMCA<br>
            7 Petroleum Street<br>
            Oil City, PA 16301<br>
            P 814-677-3000<br>
        </p>
        <p style=" font-weight: bold;float: left; padding-right: 40px">
            CLARION COUNTY YMCA<br>
            15952 Route 322, Suite 1<br>
            Clarion, PA <br>
            P 814-764-3400 <br>

        </p>
        <p style=" font-weight: bold; padding-right: 40px">
            YMCA CAMP COFFMAN<br>
            4072 Camp Coffman Rd<br>
            Cranberry, PA 16319 <br>
            P 814-677-3000 <br>

        </p>

        <div style="align: left">

            <h1 style=" font-weight: bold;font-size: 30px;text-align:left;background-color: black;color: white; padding-left: 10px ">APPLICANT INFORMATION</h1>
        </div>

        <table style=" border: 1px solid #000000">
            <tr >
                <th style="padding-right: 50px ">Last Name<br><input type="text" name="lName"></th>
                <th style="padding-right: 50px ">First Name<br><input type="text" name="fName"></th>
                <th style="padding-right: 68px ">Middle Initial<br><input type="text" name="mInitial"></th>
                <th style="padding-right: 150px "><div style=
                         "border: solid 0 #060; border-left-width:1px; padding-left:0.5ex">
                        Home Phone<br><input type="text" name="pNumber"></div>
                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 316px ">Address (street, city, state, zip)<br><input type="text" name="address" size="50"></th>
                <th style="padding-right: 150px "><div style=
                                                       "border: solid 0 #060; border-left-width:1px; padding-left:0.5ex">
                       Daytime Phone<br><input type="text" name="dayNumber"></div>
                </th>
            </tr>
        </table>
        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 316px ">Best Time/ Place to Contact You<br><input type="text" name="Contact" size="50"></th>
                <th style="padding-right: 150px "><div style=
                                                       "border: solid 0 #060; border-left-width:1px; padding-left:0.5ex">
                        Cell Phone<br><input type="text" name="cellNumber"></div>
                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 20px ">Are you at least 18 years old?
                    Yes <input type="radio" name="eighteen" id="y" value="yes" />
                    No <input type="radio" name="eighteen" id="n" value="no" />
                    <br><i style="font-size: 10px">Volunteers under 18 years of age will need written permission from parent or legal guardian</i>
                </th>
                <th>
                    Birthday
                    <input type="text" name="bMonth" size="2">
                    /<input type="text" name="bDay" size="2">
                    /<input type="text" name="bYear" size="2">
                </th>
                <th style="padding-right: 150px "><div style=
                                                       "border: solid 0 #060; border-left-width:1px; padding-left:0.5ex">
                        Email Address<br><input type="text" name="email" ></div>
                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 40px "><div style=
                                                      "border: solid 0 #060; border-right-width:1px; padding-left:0.5ex">
                    Years of Continuous Pennsylvania Residency  <input type="text" name="ResYears" size="5">
                <br>Emergency Contact Name and Telephone Number
                        <br><input type="text" name="emergencyName"> <input type="text" name="emergencyNumber"></div>
                </th>
                <th style="padding-right: 44px ">
                        Have you previously worked or volunteered at this or any other YMCA?<br><input type="text" name="history" size="50">
                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 71px ">Are you looking to fulfill a school requirement for your service?
                    Yes <input type="radio" name="requirement" id="y" value="yes" />
                    No <input type="radio" name="requirement" id="n" value="no" />
                    <br>If yes, what school
                    <input type="text" name="school" >
                </th>
                <th>Number of hours needed
                    <input type="text" name="hoursNeeded" size="4">
                    <br> Deadline to complete hours
                    <input type="text" name="deadlineMonth" size="2">
                    /<input type="text" name="deadlineDay" size="2">
                    /<input type="text" name="deadlineYear" size="2">
                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">
            <tr>
                <th style="padding-right: 327px ">Have you ever been convicted for violation of any laws, traffic or otherwise?
                    Yes <input type="radio" name="convicted" id="y" value="yes" />
                    No <input type="radio" name="convicted" id="n" value="no"  />
                    <br> If yes, please explain:
                    <br><textarea name="Text1" cols="80" rows="2"></textarea>
                    <br>Is this for court ordered community service?
                    Yes <input type="radio" name="courtOrdered" id="y" value="yes" />
                    No <input type="radio" name="courtOrdered" id="n" value="no"  />
                    <i style="font-size: 10px">Certain offenses may limit the areas in which you can serve.
                        <br> Please explain offense or bring in paperwork: </i>
                    <input type="text" name="csExplain" size="55">
                </th>
            </tr>
        </table>

        <div style="align: left">

            <h1 style=" font-weight: bold;font-size: 30px;text-align:left;background-color: black;color: white; padding-left: 10px ">ASSIGNMENT PREFERENCES (please indicate your availability)</h1>
        </div>

        <table style=" border: 1px solid #000000">
            <tr>

                <th style="padding-right: 20px; padding-left: 5px ">
                    <div style= "border: solid 0 #060; border-right-width:1px; padding-left:0.5ex">
                        Days of the Week:<br>
                    <br> <input type="checkbox" name="Monday" value="Monday"> Monday
                    <br> <input type="checkbox" name="Tuesday" value="Tuesday"> Tuesday
                    <br> <input type="checkbox" name="Wednesday" value="Wednesday"> Wednesday
                    <br> <input type="checkbox" name="Thursday" value="Thursday"> Thursday
                    <br> <input type="checkbox" name="Friday" value="Friday"> Friday
                    <br> <input type="checkbox" name="Saturday" value="Saturday"> Saturday
                    <br> <input type="checkbox" name="Sunday" value="Sunday"> Sunday
                    <br> <input type="checkbox" name="Anyday" value="Anyday"> Anyday
                    <br>
                    <br>
                    Can We contact you
                    <br>when searching for
                    <br>volunteers for various
                    events?
                    <br>Yes <input type="radio" name="convicted" id="y" value="yes"  />
                        No <input type="radio" name="convicted" id="n" value="no" />
                    </div></th>

                <th style="padding-right: 20px; padding-left: 5px ">

                       Time of Day:<br>
                        <br> <input type="checkbox" name="Mornings" value="Mornings"> Mornings
                        <br> <input type="checkbox" name="Afternoons" value="Afternoons"> Afternoons
                        <br> <input type="checkbox" name="Evenings" value="Evenings"> Evenings
                        <br> <input type="checkbox" name="Anytime" value="Anytime"> Anytime
                        <br> <input type="checkbox" name="OnlyTimes" value="OnlyTimes"> Only times listed below
                        <br>
                        <br>Specific Hours Available:
                        <br><input type="text" name="specificHours">
                        <br>Days/Times not Available:
                        <br><input type="text" name="notAvailable">
                    </th>

                <th style="padding-right: 20px; padding-left: 5px ">
                    <div style= "border: solid 0 #060; border-left-width:1px; padding-left:0.5ex">

                    What program areas interest you?<br>
                    <br> <input type="checkbox" name="anything" value="anything"> Everything/Anything
                    <br> <input type="checkbox" name="Aquatics" value="Aquatics"> Aquatics
                    <br> <input type="checkbox" name="Building" value="Building"> Building & Grounds
                    <br> <input type="checkbox" name="childCare" value="childCare"> Child Care
                    <br> <input type="checkbox" name="Family" value="Family"> Family
                    <br> <input type="checkbox" name="Financial" value="Financial"> Financial Development
                    <br>
                    <br>Specific Hours Available:
                    <br><input type="text" name="specificHours">
                    <br>Days/Times not Available:
                    <br><input type="text" name="notAvailable">
                        <br>
                        <br>
                    </div>
                    </th>

                <th style="padding-right: 20px; padding-left: 5px ">

                    <br> <input type="checkbox" name="Fitness" value="Fitness"> Fitness
                    <br> <input type="checkbox" name="officeWork" value="officeWork"> Office Work
                    <br> <input type="checkbox" name="olderAdult" value="olderAdult"> Older Adult
                    <br> <input type="checkbox" name="preschool" value="preschool"> Preschool
                    <br> <input type="checkbox" name="specialEvents" value="specialEvents"> Special Events
                    <br> <input type="checkbox" name="teens" value="teens"> Teens/Youth
                    <br> <input type="checkbox" name="teenSports" value="teenSports"> Teen Sports
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>

                </th>
            </tr>
        </table>

        <table style=" border: 1px solid #000000">

            <tr>
                <th style="padding-right: 336px; padding-left: 5px ">
                    List Specific volunteering you would like to do at the YMCA:
                    <br><textarea name="Text1" cols="80" rows="4"></textarea>
                </th>
            </tr>

        </table>





    </div>



    <br>


    <div style="background-color: white; float: left">
        <img style="align: left; width:120px; height: 120px; padding-left: 10px" src="../images/ymca_transparent.png" />

    </div>
    <div style="background-color: white">
        <h1 style=" font-weight: bold;font-size: 65px;text-align:center; ">VOLUNTEER APPLICATION</h1>
        <h1 style=" font-weight: bold;font-size: 32px;text-align:center; ">SCENIC RIVERS YMCA </h1>
        <p style=" font-weight: bold;float: left;padding-left: 10px; padding-right: 40px">
            <br>
            FOR YOUTH DEVELOPMENT®<br>
            FOR HEALTHY LIVING<br>
            FOR SOCIAL RESPONSIBILITY<br>
        </p>
        <p style=" font-weight: bold;float: left; padding-right: 40px">
            OIL CITY YMCA<br>
            7 Petroleum Street<br>
            Oil City, PA 16301<br>
            P 814-677-3000<br>
        </p>
        <p style=" font-weight: bold;float: left; padding-right: 40px">
            CLARION COUNTY YMCA<br>
            15952 Route 322, Suite 1<br>
            Clarion, PA <br>
            P 814-764-3400 <br>

        </p>
        <p style=" font-weight: bold; padding-right: 40px">
            YMCA CAMP COFFMAN<br>
            4072 Camp Coffman Rd<br>
            Cranberry, PA 16319 <br>
            P 814-677-3000 <br>

        </p>

    <body>

    <table style=" border: 1px solid #000000">

        <tr >
            <th style="padding-right: 100px; text-align: center ">References<br>Name<br>1. <input type="text" name="refName1"></th>
            <th style="padding-right: 100px; text-align: center  "><br>Telephone<br><input type="text" name="refPhone1"></th>
            <th style="padding-right: 165px; text-align: center  "><br>Relationship<br><input type="text" name="refRelation1"></th>

        </tr>

        <tr >
            <th style="padding-right: 100px; text-align: center  "><br>2. <input type="text" name="refName2"></th>
            <th style="padding-right: 100px; text-align: center  "><br><input type="text" name="refPhone2"></th>
            <th style="padding-right: 165px; text-align: center  "><br><input type="text" name="refRelation2"></th>

        </tr>

        <tr >
            <th style="padding-right: 100px; text-align: center  "><br>3. <input type="text" name="refName3"></th>
            <th style="padding-right: 100px; text-align: center  "><br><input type="text" name="refPhone3"></th>
            <th style="padding-right: 165px; text-align: center  "><br><input type="text" name="refRelation3"></th>

        </tr>
    </table>
        <p style="padding-left: 15px;">
            <br>
            I certify that all of the information provided on this Volunteer Application is true and complete to the best of my
            <br>knowledge and understand that falsified statements on this application shall be grounds for dismissal as a volunteer. I
            <br>authorize the Scenic Rivers YMCA to contact and obtain information from all references and to otherwise verify the
            <br>accuracy of all information I have provided. I understand that to insure the safety of every YMCA members, all YMCA
            <br>volunteers, who are 18 years and older, are submitted for background clearance checks prior to volunteering.
        </p>

        <table >
            <tr >
                <th style="padding-left: 15px;padding-right: 50px; text-align: center "><input type="text" name="Signature"><br>Signature</th>
                <th style="text-align: center">

                    <input type="text" name="signMonth" size="2">
                    /<input type="text" name="signDay" size="2">
                    /<input type="text" name="signYear" size="2">
                    <br> Date
                </th>

            </tr>
        </table>
        <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    </body>
    </div>

    <br>

    <div style="background-color: white; float: left; padding-left: 45px ">
        <img style="align: left; width:120px; height: 120px; padding-left: 10px" src="../images/ymca_transparent.png" />
    </div>
    <div style="background-color: white; padding-right: 45px">
        <h2 style=" font-weight: bold;font-size: 30px;text-align:right; ">SCENIC RIVERS YMCA</h2>
        <h2 style=" font-weight: bold;font-size: 30px;text-align:right; ">CODE OF CONDUCT FOR</h2>
        <h2 style=" font-weight: bold;font-size: 30px;text-align:right; ">STAFF AND VOLUNTEERS</h2>

        <div style="font-weight: bold; background-color: white; padding-left: 45px">
            1. To protect YMCA staff, volunteers, and program members, at no time during a YMCA program may a staff person
            <br>or volunteer be alone with a single child where he or she cannot be observed by others (elevator, small room, etc).
            <br>As staff or volunteers supervise children, they should space themselves in such a way that other staff can see
            <br>them.
            <br>2.	Staff and volunteers shall never leave a child unsupervised.
            <br>3. Restroom supervision: Staff will ensure: (1) The restroom is not occupied by suspicious or unknown individuals
            <br>before allowing children to use the facilities; (2) Children are with an adult staff member and proceed in groups of
            <br>three or more (e.g. 1 staff and 2 children or 2 staff .and 1 child) when using the bathroom; (3) Elth·er 'line of sight'
            <br>or 'line of sound' supervision is maintained while children are using the facilities; (4) No child, regardless of age,
            <br>enters a bathroom alone on a field trip; and (5) If staff are assisting younger children, doors to the facility must
            <br>remain open.
            <br>4. Staff and volunteers should conduct or supervise private activities in pairs - diapering, putting on bathing suits,
            <br>taking .showers, and so on. When this is not feasible, staff should be positioned so that they are visible to others.
            <br>5. Staff and volunteers shall not abuse children in any way, including:
            <br>*physical abuse - striking, spanking, shaking, slapping, etc.
            <br>*verbal abuse - humiliating, degrading, threatening, etc.
            <br>*sexual abuse - touching or speaking inappropriately.
            <br>*mental abuse - shaming, withholding kindness, being cruel, etc.
            <br>*neglect - withholding food, water, or basic care.
            <br>
            <br>Children may not be disciplined by use of physical punishment or by failing to provide the necessities of care and
            <br>doing so will be cause for immediate dismissal.
            <br>6. Staff and volunteers must use positive techniques of guidance, including redirection, positive reinforcement, and
            <br>encouragement rather than comparison, and criticism. Staff will have age-appropriate expectations an·d set up
            <br>guidelines and environments that minimize the n􀆊ed for discipline. Physical restraints of any kind are prohibited
            <br>including enclosing children In a confined or locked space.
            <br>7. Staff and volunteers will conduct a health check of each child upon his or her arrival each time the program
            <br>meets, noting any fever, bumps, bruises, burns and so on. Questions or comments will be addressed to the parent
            <br>or child In a non-threatening way. Staff will document any questionable marks or responses.
            <br>8. Program rules and boundaries must be followed, including appropriate touch guidelines. Staff will refrain from
            <br>full frontal hugging, touching of personal areas, or patting of the buttocks. Other than diapering, children are not
            <br>to be touched on areas of their bodies that would be covered by a bathing suit.
            <br>9. Staff and volunteers will refrain from Intimate displays of affection toward others in the presence of children,
            <br>parents, and staff.
            <br>10. Staff and volunteers are not to transport children in their own vehicles or allow youth participants old enough
            <br>to drive to transport younger children In the program.
            <br>11.	Staff and volunteers must appear clean, neat, and appropriately attired.
            <br>12.	Using, possessing, or being under the influence of alcohol or illegal drugs during working hours is prohibited.
            <br>13.	S.moking or use of tobacco in the presence of children or parents during working hours is prohibited.
            <br>14. Possession or use of any type of weapon or explosive device is prohibited in the Y facilities during working
            <br>hours.
            <br>15. Using YMCA computers to access pornographic sites, send e-mails with sexual overtones or otherwise inappro­
            <br>priate messages, or develop onllne relationships is not permitted.
            <br>16. Profanity, inappropriate jokes, sharing intimate details of one's personal life, and any kind of harassment in the
            <br>presence of children, parents, volunteers, or other staff is prohibited.
            <br>17. The YMCA prohibits staff/volunteers from accepting supervisory responsibilities of participant children outside
            <br>of YMCA activities. Staff and volunteers may not be alone with children they meet in the YMCA programs outside
            <br>the YMCA. This includes babysitting, sleepovers, driving or riding In cars, and Inviting children to their homes. Any
            <br>exceptions require a written explanation before the fact and are subject to administrator approval.
            <br>18. Staff and volunteers should not form inappropriate emotional or physical relationships with children who are
            <br>under the age of 18, including dating.
            <br>19. Communicating with members and program participants under the age of 18 through texting or online is pro­
            <br>hibited.
            <br>20. Staff and volunteers may not single out children for favored attention and may not give gifts to youth or their
            <br>parents.
            <br>21. Staff and volunteers must be free of physical and psychological conditions that might adversely affect chil­
            <br>dren's physical or mental health. If in doubt, an expert should be consulted.
            <br>22. Under no circumstances should staff and volunteers release children to anyone other than the authorized par­
            <br>ent, guardian, or other adult authorized by the parent or guardian (written parent authorization on file with the
            <br>YMCA).

        </div>
    </div>
    <br>
    <div style="font-weight: bold; background-color: white; padding-left: 45px">
        23. When staff and volunteers have reasonable cause to suspect child abuse, they shall report it directly to
        <br>Childline at 1-800-932-0313 and then report to the direct supervisor or Executive Director to ensure that
        <br>appropriate action has been taken. (See procedures for reporting child abuse).
        <br>24. All staff and volunteers are required to self-report within 72 hours to their YMCA supervisor if they
        <br>have been arrested or convicted of a crime.
        <br>25. Staff and volunteers are required to read and sign all policies related to identifying, documenting, and
        <br>reporting child abuse and attend trainings on the subject, as instructed by a supervisor.
        <br>26. Staff and volunteers will act in a caring, honest, respectful, and responsible manner consistent with the
        <br>mission of the YMCA and treat all children equally, regardless of sex, race, religion, culture, economic level
        <br>of the family, or disability.
        <br>27. Staff and volunteers are to report to a supervisor any other staff or volunteer who violates any of the
        <br>policies listed in this Code of Conduct.
        <br>
        <br><p style="text-align: center">I understand that any violation of this Code of Conduct may result in termination/release.</p>

        <table >
            <tr >
                <th style="padding-left: 155px;padding-right: 50px; text-align: center "><input type="text" name="finalSignature"><br>Employee/Volunteer Signature</th>
                <th style="text-align: center">

                    <input type="text" name="finalsignMonth" size="2">
                    /<input type="text" name="finalsignDay" size="2">
                    /<input type="text" name="finalsignYear" size="2">
                    <br> Date
                </th>
                <th style="padding-left: 50px;padding-right: 10px; text-align: center "><input type="text" name="finalSignature"><br>Supervisor Signature</th>

            </tr>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
            <button id="progressBar" onclick="location.href='../controller/controller.php?action=CriminalClearance'">Next</button>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>



    </div>
    </form>




<?php
    require_once '../view/footerInclude.php';
?>