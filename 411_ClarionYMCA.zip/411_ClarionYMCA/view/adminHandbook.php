<?php
    $title = "Admin Volunteering Form";
    require_once '../view/headerInclude.php';
?>

<section id="main" class="align-content-center">
    <div class="text-center">
        <!-- Pull *User* from db using accountID -->
        <h1>Volunteering Form for *User*</h1>
        <br>
        <p>
            Please take the time to read through this <a href="../pdfs/WelcomeToVolunteering.pdf">handbook</a> - it is full of helpful information for volunteers.
        </p>

        <br>

        <p>
            Even if you have volunteered with us in the past, we still ask that read it in the event a policy has changed.
        </p>

        <br>

        <p>
            By signing this document, I <input type="text" name="welcomePrint" value = "*User pulled from DB*"> agree that I read and will demonstrate the contents of:
        </p>

        <span>
            <ul>Code of Conduct</ul>
            <ul>Expectation for you and us</ul>
            <ul>Emergencies and Weather</ul>
            <ul>Clearances and Waiver</ul>
            <ul>Child Abuse Awareness</ul>
            <ul>Delivering a meaningful practice</ul>
            <span>
                <ul>Planning</ul>
                <ul>Behavior Management</ul>
            </span>
        </span>

        <br>

        <p>
            I agree to uphold the principles of this agreement and the values of the YMCA. I
            understand that any infringement of these may result in my dismissal and/or
            reporting to the appropriate authorities.
        </p>

        <br>

        <p>
            Volunteer: <input type="text" name="welcomeName" value = "User pulled from DB" ><br>
        </p>

        <br>

        <p>
            <!-- Pull supervisors from database -->
            Supervisor: <select> <option value = "James Collins">James Collins</option> <option value = "someoneElse">Someone Else</option> </select><br>
        </p>

        <br>

        <p>
            <!-- pull date from database -->
            Date: <input type="date" value ="<?php echo date('Y-m-d') ?>">
        </p>
        <p>
            <button>Save Changes</button>
            <button>Back to User Information</button>
        </p>
    </div>

<?php
    require_once '../view/footerInclude.php';
?>