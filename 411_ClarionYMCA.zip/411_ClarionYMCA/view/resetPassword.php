<!--Author: Josh Dunleavy
    Purpose: This form will allow a volunteer to change their current password, 
    as long as they 
    LastModified: 3/9/19
     -->
<!--Adds title to tab and header to page-->
    <?php
        //Variable used to add title to the tab
        $title = "Change Password";
        require_once '../view/headerInclude.php';
    ?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <!--Heading of page-->
            <h1>Change Password</h1>
            
        </div>
    <!--End of section -->
    </section>

    <form class="text-center">

        <!--Label for Email-->
        <label for="email">
            Email Address:
        </label>
        <!--Input is set to email type-->
        <input type="email" id="email "name="email"><br>
        

        <!--Label for old password -->
        <label for="oldPassword">
            Old Password:
        </label>
        <!--Input set to password-->
        <input type="password" name="oldPassword" id="oldPassword"><br>
         <!--Label for  -->
        
        
        
        
        
        
         <label for="newPassword">
         New Password:
        </label>
        
        <!--Input set to password-->
        <input type="password" name="newPassword" id="newPassword"><br>
       

        <label for="retypedNewPassword">
            Retype Password:
        </label>


        <!--Input set to password used to make sure new that volunteer doesn't make an error in there new password-->
        <input type="password" name="retypedNewPassword" id="retypedNewPassword"><br>
        <!--Submits information-->
        <!--m-2 adds margins -->
        <input class="m-3 rounded" type="submit" name="submit">         
    </form>


    <!-- Adds footer to game-->
    <?php
        require_once '../view/footerInclude.php';
    ?>
    <!-- -->