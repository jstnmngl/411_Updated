<?php
    $title = "Introduction";
    require_once '../view/headerInclude.php';
?>

<script>
    var module1 = 0;
    var module2 = 0;
    var module3 = 0;
    var module4 = 0;
    var module5 = 0;
    var sum = module1+module2+module3+module4+module5;
    localStorage.setItem("percentComplete", sum);
    progress();
</script>

<section id="main" class="align-content-center">
    <div class="text-center">
        <h1>Introduction Page</h1>
        <p>
            We take child protection seriously here. You will need to complete some paperwork before we can welcome you to the SCENIC RIVERS family.
            This software is designed to make the process of applying to volunteer with us quick and easy.
        </p>

        <br>

        <p>
            Once you have submitted a completed application you will not have to repeat the process if you wish to re-apply in the future.
        </p>

        <br>

        <p>
            Before you begin please insure you have ready:
                <ul>Social Security Card</ul>
                <ul>Any forms of ID</ul>
                <ul>A witness to verify future information provided is correct</ul>
                <ul>An electronic copy of your PA Child Abuse Clearance (if you have one)</ul>
                <ul>An electronic copy of your Criminal Record Check (if you have one)*</ul>

                <p>*Please note that having a criminal record does not necessarily exclude you from volunteering with us. These are considered on a case by case basis.</p>
        </p>

        <button id="progressBar" onclick="location.href='../controller/controller.php?action=Handbook'">Next</button>
    </div>
</section>

<?php
    require_once '../view/footerInclude.php';
?>
