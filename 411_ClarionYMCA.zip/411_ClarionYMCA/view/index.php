<?php
    $title = "Clarion YMCA";
    require_once '../view/headerInclude.php';
?>

<section id="main" class="align-content-center">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!--Wrapper for slides -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../images/carousel/placeholder.png" height="500" width="1100" alt="image1">
            </div>

            <div class="carousel-item">
                <img src="../images/carousel/placeholder.png" height="500" width="1100" alt="image2">
            </div>

            <div class="carousel-item">
                <img src="../images/carousel/placeholder.png" height="500" width="1100" alt="image3">
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
</section>

<body class="col-12 text-center media-body">
    <br>

    <h1>This is main content</h1>
    <p>
        Volunteering with us can be hugely rewarding. You will have the opportunity to positively contribute to the lives of the children we serve.
        We are proud, as an organisation, to have such a dedicated team of volunteers dedicated to supporting us in our mission:
    </p>

    <br>

    <p>
        To put Christian principles into practice through programs that build healthy spirit, mind and body for all.
    </p>

    <br>

    <p>
        Please continue to begin the application process. (This takes about 15m)
    </p>
</body>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>Sign In/Sign Up</h1>
            <button onclick="location.href='../view/loginPage.php'" type="button">Sign In</button>
            <button onclick="location.href='../view/registerPage.php'" type="button"> Sign Up</button>
        </div>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>