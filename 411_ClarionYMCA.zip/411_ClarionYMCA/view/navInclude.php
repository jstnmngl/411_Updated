<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <a class="navbar-brand d-md-none d-lg-block" href="../view/index.php">Clarion YMCA NavBar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="../controller/controller.php?action=Home">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=Introduction">Introduction</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=Handbook">Handbook</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=Application">Application</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=CriminalClearance">Criminal</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=ChildAbuseClearance">Abuse</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=Waiver">Waiver</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=SignIn"><i class="fas fa-sign-in-alt"></i> Sign In</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../controller/controller.php?action=AddUserForm"><i class="far fa-envelope"></i> Sign Up</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminActivities">Activities</a>
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminSupervisors">Supervisors</a>
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminHandbook">Handbook</a>
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminApplication">Application</a>
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminWaiver">Waiver</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="../controller/controller.php?action=AdminHome">Admin Home</a>
                </div>
            </li>
        </ul>
    </div>
</nav>