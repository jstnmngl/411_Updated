<!--Author: Josh Dunleavy
    Purpose: This page will be used as a framework to build all future pages off of
    LastModified: 3/5/19
-->

    <!--Adds title to tab and header to page-->
    <?php
        //Variable used to add title to the tab
        $title = "Information Admin";
        require_once '../view/headerInclude.php';
    ?>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <!--Heading of page-->
            <h1>Information Admin</h1>
            <p>insert paragraph here that describes the main introduction and provide all links</p>
        </div>
    <!--End of section -->
    </section>

    <!--This section will hold the Volunteer who's information you are currently viewing-->
    <div>
        <!--This php code will be used to show the Volunteer name-->
        <?php
            //Variable will populate the this echo with volunteers name
            echo"<p>Viewing: Volunteer name Information</p>"; 
        ?>
        <!--This form will hold a button to View Application page-->
        <!--<form  method="get" action="../view/welcomePage.php">-->
        <!-- Div to hold buttons-->
        <div>
            <!--Button to take admin to volunteers application-->
            <button>
                View Application
            </button>
        <!--button to View Waiver page-->
            <button>
                View Waiver
            </button>
        <!--button to View Clearances page-->
            <button>
                View Clearances
            </button>
        </div>
        <!--This form will hold equipment checked out and supervisor-->
        <div>
        <!--php block will populate form with information about this specific Volunteer selected-->
        
            <!--Displays if Volunteer currently borrowing equipment-->
            <p>Equipment Checked out: equipment</p>

            <!--Displays Volunteer supervisors name-->
           <p>SuperVisor: superName</p>
       
        <!--End of form-->
        </div>  
    </div>

        <!--This section holds forms that have buttons-->
        <div>
            <!--This form will hold a button to print all page--> 
            <button type="submit">
                Print All Forms
            </button>
            <!--This form will hold a button to edit forms-->   
            <button type="submit">
                Edit Forms
            </button>
            <!--This form will hold a button to save and changes made-->
            <button type="submit">
                Save Changes
            </button>
        </div>












    <!--Adds footer to game-->
    <?php
        require_once '../view/footerInclude.php';
    ?>
    <!-- -->
