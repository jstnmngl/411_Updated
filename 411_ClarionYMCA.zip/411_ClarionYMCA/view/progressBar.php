<div class="progress" id="container">
    <div class="progress-bar" id="progressLevel" role="progressbar"></div>
</div>