<?php
    $title = "Admin Home";
    require_once '../view/headerInclude.php';
?>

<section id="main" class="align-content-center">
    <div class="text-center">
        <h1>Admin Home</h1>
    </div>
    <div class="container-fluid" id="tables">
        <div class="row ">
            <div class="col-lg-12 col-md-12 col-xs-12">
                <h2 class="text-center">Users Completed</h2>
                <div class="scrollable">
                    <table class="table table-fixed table-bordered text-center">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Waiver expiration</th>
                                <th>Clearance expiration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <td>Johnny Appleseed</td>
                            <td><a href="mailto:jApples@gmail.com">jApples@gmail.com</a></td>
                            <td>4/4/2019</td>
                            <td>3/4/2024</td>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-xs-12">
                <h2 class="text-center">Users Signed Up</h2>
                <div class="scrollable">
                    <table class="table table-fixed table-bordered text-center">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Date Registered</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Johnny Appleseed</td>
                                <td><a href="mailto:jApples@gmail.com">jApples@gmail.com</a></td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>3/4/2019</td>
                            </tr>
                        </tbody>
                </div>
                </table>
            </div>
            <div class="col-lg-12 col-md-12 col-xs-12">
                <h2 class="text-center">Users In Progress</h2>
                <div class="scrollable">
                    <table class="table table-fixed table-bordered text-center">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Matt Chapman</td>
                                <td><a href="mailto:mattchappy616@gmail.com">mattchappy616@gmail.com</a></td>
                                <td>60%</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>60%</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>60%</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>60%</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>60%</td>
                            </tr>
                            <tr>
                                <td>Matt Chapman</td>
                                <td>mattchappy616@gmail.com</td>
                                <td>60%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row" id="adminButtons">
                <div class="col-md-3 col-sm-3 col-xs-6 text-center">
                    <button class="">See Supervisors</button>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 text-center">
                    <button>See Activities</button>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 text-center">
                    <button>See User Information</button>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6 text-center">
                    <button>Delete a Volunteer</button>
                </div>
            </div>
            <div>
            </div>
</section>

<?php
    require_once '../view/footerInclude.php';
?>