<!-- Footer Section -->
<footer>
    <hr>
    <div class="media">
        <div class="media-body col-12 text-center"">
            <p>
                The Scenic Rivers Association does not and shall not discriminate on the basis of race, color, religion (creed),
                gender, gender expression, age, national origin (ancestry), disability, marital status, sexual orientation, or military status, in any of its activities or operations.
            </p>
        <br>
            <p>
                Our mission: To put Christian principles into practice through programs that build healthy spirit, mind and body for all.
            </p>
            <p>
                Copyright &copy; Clarion YMCA
            </p>
        </div>
    </div>
</footer>
