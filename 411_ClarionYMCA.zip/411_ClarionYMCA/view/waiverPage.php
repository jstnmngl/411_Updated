<?php
    $title = "Volunteer Waiver";
    require_once '../view/headerInclude.php';
?>

    <script>
        var module1 = 1;
        var module2 = 1;
        var module3 = 1;
        var module4 = 1;
        var module5 = 0;
        var sum = module1+module2+module3+module4+module5;
        localStorage.setItem("percentComplete", sum);
        progress();
    </script>

    <section id="main" class="align-content-center">
        <div class="text-center">
            <h1>
                Oil City YMCA
                <br>
                Employee Disclosure Statement
            </h1>
            <p>(Required by Child Protective Services Law, 23 Pa, C.S.A. 6344(m))</p>

            <br>

            <p>
                I swear/affirm that I have mailed the request for clearances to ChildLine, the Pennsylvania State Police
                and the Federal Bureau of Investigation (where applicable).
            </p>

            <br>

            <p>
                I swear/affirm that I have not been named as a perpetrator of a founded report of child abuse as defined
                by the Child Protective Services Law within the preceding five years.
            </p>

            <br>

            <p>
                I swear/affirm that I have not been convicted of one or more of the following crimes under Title 18 of
                the Pennsylvania Consolidated Statutes or equivalent crime in another state.
            </p>

            <div>
                <ul>Chapter 25 (relating to criminal homicide)</ul>
                <ul>Section 2702 (relating to aggravated assault)</ul>
                <ul>Section 2901 (relating to kidnapping)</ul>
                <ul>Section 2902 (relating to unlawful restraint)</ul>
                <ul>Section 3121 (relating to rape)</ul>
                <ul>Section 3122 (relating to statutory rape)</ul>
                <ul>Section 3123 (relating to involuntary deviant sexual intercourse)</ul>
                <ul>Section 3125 (relating to aggravated indecent assault)</ul>
                <ul>Section 3126 (relating to indecent assault)</ul>
                <ul>Section 3127 (relating to indecent exposure)</ul>
                <ul>Section 4303 (relating to concealing death of child born out of wedlock)</ul>
                <ul>Section 4304 (relating to endangering welfare of children)</ul>
                <ul>Section 4305 (relating to dealing in infant children)</ul>
                <ul>Section 5902(b) (relating to prostitution and related offenses)</ul>
                <ul>Section 5903(c) or (d) (relating to obscene and other sexual materials and performances)</ul>
                <ul>Section 6301 (relating to corruption of minors)</ul>
                <ul>Section 6312 (relating to sexual abuse of children)</ul>
            </div>

            <br>

            <p>
                I understand that as a provisionally hired employee, I must work within the eyesight of a permanent employee at all times.
            </p>

            <br>

            <p>
                I understand that I must be dismissed if I have been named as a perpetrator of a founded report of child
                abuse within the past five years or have been convicted of any of the crimes listed above.
            </p>

            <br>

            <p>
                I understand that my employment may be terminated if I have been named as a perpetrator of a founded report
                of child abuse longer than five years ago or the perpetrator of an indicated report of child abuse.
            </p>

            <br>

            <p>
                I hereby swear/affirm that the information as set forth above is true and correct. I understand that the
                penalty for false swearing is a misdemeanor of the third degree pursuant to Section 4903(b) of the Crimes Code.
            </p>

            <br>

            <p>
                Date: <input type="date" name="waiverDate" value ="<?php echo date('Y-m-d') ?>"><br>
            </p>

            <br>

            <p>
                Name: <input type="text" name="waiverName"><br>
            </p>

            <br>

            <p>
                Witness: <input type="text" name="waiverWitness"><br>
            </p>

            <br>

            <p>
                Signature: <input type="text" name="waiverSignature"><br>
            </p>
            <button id="progressBar" onclick="location.href='../controller/controller.php?action=CompleteApplication'">Submit Volunteer Application</button>
        </div>
    </section>

<?php
    require_once '../view/footerInclude.php';
?>