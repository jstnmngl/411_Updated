<?php
    $title = "Welcome to Volunteering";
    require_once '../view/headerInclude.php';
?>

<script>
    var module1 = 1;
    var module2 = 0;
    var module3 = 0;
    var module4 = 0;
    var module5 = 0;
    var sum = module1+module2+module3+module4+module5;
    localStorage.setItem("percentComplete", sum);
    progress();
</script>

<section id="main" class="align-content-center">
    <div class="text-center">
        <!-- Pull *User* from db using accountID -->
        <h1>Welcome to Volunteering!</h1>
        <br>
        <p>
            Please take the time to read through this <a href="../pdfs/WelcomeToVolunteering.pdf">handbook</a> - it is full of helpful information for volunteers.
        </p>

        <br>

        <p>
            Even if you have volunteered with us in the past, we still ask that you read it in the event a policy has changed.
        </p>

        <br>

        <p>
            By signing this document, I <input type="text" name="welcomePrint"> agree that I read and will demonstrate the contents of:
        </p>

        <span>
            <ul>Code of Conduct</ul>
            <ul>Expectation for you and us</ul>
            <ul>Emergencies and Weather</ul>
            <ul>Clearances and Waiver</ul>
            <ul>Child Abuse Awareness</ul>
            <ul>Delivering a meaningful practice</ul>
            <span>
                <ul>Planning</ul>
                <ul>Behavior Management</ul>
            </span>
        </span>

        <br>

        <p>
            I agree to uphold the principles of this agreement and the values of the YMCA. I
            understand that any infringement of these may result in my dismissal and/or
            reporting to the appropriate authorities.
        </p>

        <br>

        <p>
            Volunteer: <input type="text" name="welcomeName"><br>
        </p>

        <br>

        <p>
            Supervisor: <select> <option value = "James Collins">James Collins</option> <option value = "someoneElse">Someone Else</option> </select><br>
        </p>

        <br>

        <p>
            Date: <input type="date" value ="<?php echo date('Y-m-d') ?>">
        </p>
        <br>

        <p>
            <button id="progressBar" onclick="location.href='../controller/controller.php?action=Application'">Next</button>
        </p>
    </div>

<?php
    require_once '../view/footerInclude.php';
?>
