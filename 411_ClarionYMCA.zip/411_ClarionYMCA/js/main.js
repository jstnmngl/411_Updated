window.onload = function() {
    document.getElementById("progressBar").addEventListener("click", progress);
}

//size on initial load
$(document).ready(function() {
    resizeCarouselImages();
})

//resizes if orientation changes
$(document).resize(function() {
    resizeCarouselImages();
})

function resizeCarouselImages() {
    if (window.innerWidth < 1100) {
        var width = window.innerWidth - 10;
        var ratio = width / 1100;
        var height = ratio * 500;
        $(".carousel-item img").width(width);
        $(".carousel-item img").height(height);
    }
}

function progress(){
    var element = document.getElementById("progressLevel");
    var percent = localStorage.getItem("percentComplete");

    if(percent == 1) {
        var width = 20;
        element.style.width = width + "%";
    } else if (percent == 2) {
        var width = 40;
        element.style.width = width + "%";
    } else if (percent == 3) {
        var width = 60;
        element.style.width = width + "%";
    } else if (percent == 4) {
        var width = 80;
        element.style.width = width + "%";
    } else if (percent == 5) {
        var width = 100;
        element.style.width = width + "%";
    } else {
        var width = 0;
        element.style.width = width + "%";
    }
}