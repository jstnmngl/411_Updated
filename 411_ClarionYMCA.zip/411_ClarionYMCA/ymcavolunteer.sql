-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2019 at 09:08 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ymcavolunteer`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `accountID` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `birthDate` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  `dateRegistered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activityID` int(11) NOT NULL,
  `volunteerID` int(11) DEFAULT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `addressID` int(11) NOT NULL,
  `volunteerID` int(11) NOT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `availabilityID` int(11) NOT NULL,
  `volunteerID` int(11) NOT NULL,
  `days` varchar(10) NOT NULL,
  `hours` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hours`
--

CREATE TABLE `hours` (
  `hoursID` int(11) NOT NULL,
  `volunteerID` int(11) NOT NULL,
  `date` date NOT NULL,
  `hours` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prevaddress`
--

CREATE TABLE `prevaddress` (
  `prevAddressID` int(11) NOT NULL,
  `volunteerID` int(11) NOT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reference`
--

CREATE TABLE `reference` (
  `referenceID` int(11) NOT NULL,
  `volunteerID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `telephone` varchar(11) NOT NULL,
  `relationship` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `supervisorID` int(11) NOT NULL,
  `activityID` int(11) DEFAULT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE `volunteer` (
  `volunteerID` int(11) NOT NULL,
  `accountID` int(11) NOT NULL,
  `yearsOfResidency` varchar(2) DEFAULT NULL,
  `currentAddressLength` varchar(2) DEFAULT NULL,
  `previousVolunteer` varchar(1) DEFAULT NULL,
  `previousDate` date DEFAULT NULL,
  `previousPosition` text,
  `conviction` varchar(50) DEFAULT NULL,
  `convictionExplanation` text,
  `courtOrdered` varchar(1) DEFAULT NULL,
  `courtExplanation` text,
  `interviewedBy` text,
  `dateInterviewed` date DEFAULT NULL,
  `department` text,
  `supervisor` varchar(50) DEFAULT NULL,
  `appCompleted` varchar(1) NOT NULL DEFAULT 'N',
  `dateChildAbuseSubmitted` date DEFAULT NULL,
  `dateCriminalCheckSubmitted` date DEFAULT NULL,
  `picChildAbuse` blob,
  `picCriminalCheck` blob,
  `dateWelcomeCompleted` int(11) DEFAULT NULL,
  `dateWaiverCompleted` date DEFAULT NULL,
  `witness` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`accountID`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activityID`),
  ADD KEY `activity_volunteer_fk` (`volunteerID`) USING BTREE;

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addressID`),
  ADD KEY `volunteerID` (`volunteerID`) USING BTREE;

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`availabilityID`),
  ADD KEY `availability_volunteer_fk` (`volunteerID`) USING BTREE;

--
-- Indexes for table `hours`
--
ALTER TABLE `hours`
  ADD PRIMARY KEY (`hoursID`),
  ADD KEY `hours_volunteer_fk` (`volunteerID`) USING BTREE;

--
-- Indexes for table `prevaddress`
--
ALTER TABLE `prevaddress`
  ADD PRIMARY KEY (`prevAddressID`),
  ADD KEY `prevAddress_volunteer_fk` (`volunteerID`) USING BTREE;

--
-- Indexes for table `reference`
--
ALTER TABLE `reference`
  ADD PRIMARY KEY (`referenceID`),
  ADD KEY `reference_volunteer_FK` (`volunteerID`) USING BTREE;

--
-- Indexes for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD PRIMARY KEY (`supervisorID`),
  ADD KEY `supervisor_activity_fk` (`activityID`) USING BTREE;

--
-- Indexes for table `volunteer`
--
ALTER TABLE `volunteer`
  ADD PRIMARY KEY (`volunteerID`),
  ADD KEY `application_account_FK` (`accountID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `accountID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `activityID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addressID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `availabilityID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hours`
--
ALTER TABLE `hours`
  MODIFY `hoursID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prevaddress`
--
ALTER TABLE `prevaddress`
  MODIFY `prevAddressID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reference`
--
ALTER TABLE `reference`
  MODIFY `referenceID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supervisor`
--
ALTER TABLE `supervisor`
  MODIFY `supervisorID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `volunteer`
--
ALTER TABLE `volunteer`
  MODIFY `volunteerID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activity_volunteer_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_volunteer_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `availability`
--
ALTER TABLE `availability`
  ADD CONSTRAINT `availability_volunteer_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `hours`
--
ALTER TABLE `hours`
  ADD CONSTRAINT `hours_volunteers_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `prevaddress`
--
ALTER TABLE `prevaddress`
  ADD CONSTRAINT `prevAddress_volunteer_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `reference`
--
ALTER TABLE `reference`
  ADD CONSTRAINT `reference_volunteer_fk` FOREIGN KEY (`volunteerID`) REFERENCES `volunteer` (`volunteerID`) ON UPDATE CASCADE;

--
-- Constraints for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD CONSTRAINT `supervisor_activity_fk` FOREIGN KEY (`activityID`) REFERENCES `activities` (`activityID`) ON UPDATE CASCADE;

--
-- Constraints for table `volunteer`
--
ALTER TABLE `volunteer`
  ADD CONSTRAINT `application_account_fk` FOREIGN KEY (`accountID`) REFERENCES `account` (`accountID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
